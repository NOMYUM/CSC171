Name: Angela Chung 
Net ID: 30612068 
Assignment: 17
lab section: MW 2 00 - 3 15 pm

Question1:
Implements an ArrayList class that stores a list (of objects) using an array. The
class has an append method to add an element to the list. The main method
demonstrates the use of the class and method, on Integers or instances of
whatever class

Question2:
Add a toString() method that returns a String representation of an ArrayList
and use it in the main method

Question3:
Add a prepend method to add an element at the front of an ArrayList

Question4:
Make the class generic by adding a generic type parameter and using it appropriately
throughout the code

Question5:
Add the prepend method that adds a new Object to the front of the list.

Question6:
Add a method indexOf(Object e) that returns the index of the given object in the
list, or -1 if the object is not in the list.

Quesiton7:
Add a method get(int i) that returns the object at the given index in the list, or
throws an IndexOutOfBoundsException if there is no such element in the list.

Question8:
Add an instance variable last and use it to implement an efficient (fast) append
method that adds a new Object at the end of the list.

Question9:
Make your class generic by adding a generic type parameter and using it appropriately
throughout the code.