Name: Angela Chung 
Net ID: 30612068 
Assignment: 14
lab section: MW 2 00 - 3 15 pm

Question 1
My program that can read in a series of numbers from the user until they enter “0”
and store the numbers in a List of Integers. Then asks the user for a number and
report whether it is one of the numbers that was read in.

Question 2
A program that can read a series of strings from the user and store them in a List
of Strings. Then read another string from the user, and iterate over the elements of
the List and report whether the target string is equal (as in equals) to any element
of the list. 

Question 3
Similar to the question 2, write program that can read a List of Strings and
a final target string. This time iterate over the elements of the list and report the index
of any element that is equal (as in equals) to the target string. 

Question 4
A program with a static boolean method that takes as parameter a List and two
integer indexes and reports whether the elements at the two indexes in the List are
equal (as in equals). 

Question 5
A program that reads in a series of names and eliminates duplicates by storing
them in a Set of Strings. Then asks the user for a name and report whether it was
one of the names that was read in.

Question 6
A simple phonebook program that reads in a series of name-number pairs from
the user (that is, name and number on one line separated by whitespace) and stores
them in a Map from Strings to Integers. Then asks the user for a name and return
the matching number, or tell the user that the name wasn’t found.