Name: Angela Chung 
NetID: 30612068
Assignment Number: 13
Lab section day/time: MW 2:00-3:15PM

Question 1
Created a simple Swing application that animates a square shape diagonally across its window
once.

Question 2
Extended my application from the Question1 to do the following:
• Have the animation work properly even if the window is resized
• Have the animation restart at the beginning once the shape reaches the other side.

Question 3
Created an application that animates a square around a circular path centered in the
application’s window. That is, you’re drawing a square whose position changes in time
along a circular path. The animation should stop after one complete rotation.

Question 4
Created a “screen saver” application that can create a graphical application that draws 100 
random lines in a canvas,extended my application so that it repaints itself every five seconds,
extended my application to provide a GUI for setting the number of lines to draw.