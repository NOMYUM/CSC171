Name: Angela Chung 
Net ID: 30612068 
Assignment: 16
lab section: MW 2 00 - 3 15 pm

QUESTION 1
A recursive function that multiplies two numbers x and y. The main method
prompts the user for the two numbers, call function, and print the result.

QUESTION 2
A recursive method that checks whether a given number is a numerical palindrome.

QUESTION 3
A recursive method that computes the nth Lucas number and have the main
method illustrate its use.

QUESTION 4
A recursive method that computes the nth Fibonacci word and have your main
method illustrate its use.